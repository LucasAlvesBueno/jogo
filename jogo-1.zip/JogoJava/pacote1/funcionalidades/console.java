package pacote1.funcionalidades;

public class console {

    public static void apagarConsole() {

        for (int i = 0; i < 30; i++) {
            System.out.println("");
        }

    }

}
