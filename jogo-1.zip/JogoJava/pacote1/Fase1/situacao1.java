package pacote1.Fase1;
import pacote1.funcionalidades.console;
import pacote1.personagens.Personagem;

import java.util.ArrayList;
import java.util.List;

public class situacao1 {

    List<Personagem> listaDeInimigos = new ArrayList<>();


    
    public static void goblinsCombat(){
        console.apagarConsole();
        System.out.println("Dois goblins mal intencionados caminham em sua direção...\n\nUm combate se inicia!");



    }
    public static void oQueVcFaz(){

            System.out.println("\nO que você faz?\n");


    }



}
