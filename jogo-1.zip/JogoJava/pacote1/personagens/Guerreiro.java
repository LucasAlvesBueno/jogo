package pacote1.personagens;

public class Guerreiro extends Personagem {
    
public Guerreiro(String nome, int nivel, int vida, int forca, int poder, int folego, int mana, int armadura,
int resMgc,String classe){
    super(nome, nivel, vida, forca, poder, folego, mana, armadura, resMgc,classe);
}

}
